# GONEP Database Migration Package

This package contains all database migrations for the GONEP Healthcare system.

## Contents

- **consolidated_migration.sql** - Complete migration file ready for execution
- **migrations/** - Individual migration files
- **migration_order.txt** - Order of migration execution
- **README.md** - This file

## Quick Start

### Option 1: Use Consolidated File (Recommended)
1. Upload the `consolidated_migration.sql` file to phpMyAdmin
2. Select your database
3. Go to SQL tab
4. Paste the content and execute

### Option 2: Use Individual Files
1. Execute migrations in the order specified in `migration_order.txt`
2. Each file should be run separately in sequence

## Database Requirements

- MySQL 8.0+ or MariaDB 10.5+
- UTF8MB4 character set
- InnoDB storage engine

## Tables Created

This migration will create the following tables:

1. 0000_conscious_hiroim
2. 0001_add_job_details_fields
3. 0001_superb_talkback
4. 0002_hard_devos
5. 0002_update_demo_requests_table
6. 0003_busy_thunderbolt
7. 0003_enhance_team_members_table
8. 0004_create_demo_config_tables
9. 0005_add_placement_to_demo_videos
10. 0005_create_demo_videos_table

## Important Notes

- **Always backup your database before running migrations**
- Ensure you have sufficient privileges to create tables
- The consolidated file includes proper transaction handling
- Foreign key checks are temporarily disabled during migration

## Support

If you encounter issues, check the migration logs and ensure all prerequisites are met.
